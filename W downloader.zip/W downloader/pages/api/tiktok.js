export default async function handler(req, res) {
  try {
    const { url } = req.query;
    if (!url) return res.status(400).json({ error: 'URL tidak diberikan.' });

    const apiURL = `https://api.tiklydown.me/api/download?url=${encodeURIComponent(url)}`;

    const r = await fetch(apiURL);
    const j = await r.json();

    const video = j.video || j.videoUrl || j.download;
    if (!video) return res.status(500).json({ error: 'Gagal mengambil video.' });

    res.status(200).json({
      video,
      title: j.title || ''
    });

  } catch (err) {
    res.status(500).json({ error: 'Server error: ' + err.message });
  }
}