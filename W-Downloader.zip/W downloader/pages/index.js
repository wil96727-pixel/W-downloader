import { useState } from 'react';

export default function Home() {
  const [url, setUrl] = useState('');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const download = async () => {
    if (!url.trim()) return alert('Tempel URL TikTok dulu.');
    setLoading(true);
    try {
      const res = await fetch(`/api/tiktok?url=${encodeURIComponent(url)}`);
      const data = await res.json();
      if (data.error) { alert(data.error); setLoading(false); return; }
      setResult(data);
    } catch (e) {
      alert('Gagal: ' + e.message);
    }
    setLoading(false);
  };

  return (
    <div style={{fontFamily:'sans-serif', padding:20, maxWidth:720, margin:'0 auto', textAlign:'center'}}>
      <h1>W Downloader</h1>
      <p>Masukkan link TikTok, lalu tekan Download.</p>

      <input
        placeholder="Tempel URL TikTok"
        value={url}
        onChange={e => setUrl(e.target.value)}
        style={{width:'100%', padding:12, fontSize:16, borderRadius:8, border:'1px solid #ddd'}}
      />
      <div style={{marginTop:10}}>
        <button onClick={download} style={{padding:'10px 18px', fontSize:16}}>
          {loading ? 'Processing...' : 'Download'}
        </button>
      </div>

      {result?.video && (
        <div style={{marginTop:30}}>
          <h3>{result.title || 'Video'}</h3>

          <div style={{ position:'relative', display:'inline-block' }}>
            <video src={result.video} controls width={360} style={{borderRadius:8}} />
            <img
              src="/watermark.png"
              alt="W watermark"
              style={{
                position:'absolute',
                bottom:10,
                right:10,
                width:120,
                opacity:0.8,
                pointerEvents:'none'
              }}
            />
          </div>

          <div style={{marginTop:16}}>
            <a href={result.video} download>
              <button style={{padding:'10px 16px', fontSize:16}}>Download Video</button>
            </a>
          </div>
        </div>
      )}
    </div>
  );
}